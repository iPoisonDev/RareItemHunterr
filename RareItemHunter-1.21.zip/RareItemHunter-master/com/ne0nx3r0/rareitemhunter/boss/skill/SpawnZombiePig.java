package com.ne0nx3r0.rareitemhunter.boss.skill;

import com.ne0nx3r0.rareitemhunter.boss.BossSkillSpawn;
import org.bukkit.entity.EntityType;

public class SpawnZombiePig extends BossSkillSpawn
{
    public SpawnZombiePig()
    {
        super("Spawn Zombie Pig",EntityType.PIG_ZOMBIE);
    }
}
