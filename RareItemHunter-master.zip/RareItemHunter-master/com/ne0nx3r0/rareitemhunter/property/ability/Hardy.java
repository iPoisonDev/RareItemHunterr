package com.ne0nx3r0.rareitemhunter.property.ability;

import com.ne0nx3r0.rareitemhunter.property.ItemProperty;
import com.ne0nx3r0.rareitemhunter.property.ItemPropertyTypes;

public class Hardy extends ItemProperty
{
    public Hardy()
    {
        super(ItemPropertyTypes.ABILITY,"Hardy","-1 damage / lvl",3,0);
    }
}
