package com.ne0nx3r0.rareitemhunter.boss;

public enum BossEventType
{
    hpLessThan;
}
