package com.ne0nx3r0.rareitemhunter.boss.skill;

import com.ne0nx3r0.rareitemhunter.boss.BossSkillSpawn;
import org.bukkit.entity.EntityType;

public class SpawnSilverfish extends BossSkillSpawn
{
    public SpawnSilverfish()
    {
        super("Spawn Silverfish",EntityType.SILVERFISH);
    }
}
