package com.ne0nx3r0.rareitemhunter.boss.skill;

import com.ne0nx3r0.rareitemhunter.boss.BossSkillSpawn;
import org.bukkit.entity.EntityType;

public class SpawnCreeper extends BossSkillSpawn
{
    public SpawnCreeper()
    {
        super("Spawn Creeper",EntityType.CREEPER);
    }
}
