package com.ne0nx3r0.rareitemhunter.boss.skill;

import com.ne0nx3r0.rareitemhunter.boss.BossSkillSpawn;
import org.bukkit.entity.EntityType;

public class SpawnCaveSpider extends BossSkillSpawn
{
    public SpawnCaveSpider()
    {
        super("Spawn Cave Spider",EntityType.CAVE_SPIDER);
    }
}
