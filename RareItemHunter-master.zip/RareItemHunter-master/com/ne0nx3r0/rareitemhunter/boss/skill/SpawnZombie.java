package com.ne0nx3r0.rareitemhunter.boss.skill;

import com.ne0nx3r0.rareitemhunter.boss.BossSkillSpawn;
import org.bukkit.entity.EntityType;

public class SpawnZombie extends BossSkillSpawn
{
    public SpawnZombie()
    {
        super("Spawn Zombie",EntityType.ZOMBIE);
    }
}
