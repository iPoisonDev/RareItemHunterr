export const Puzzles: Record<string, string> = {
    bunker_eye_02: "egg,hydra,storm,conch,crossing,hatchet",
    bunker_chrys_01: "ichi,ni,san,shi",
    saloon: "red,orange,yellow,green,blue,indigo,violet",
    club_01: "1,2,3,4",
    club_02: "1",
};
