export const api = {
    resolveUrl: function (url: string) {
        return url;
    },
    resolveRoomHost: function () {
        return window.location.host;
    },
};
